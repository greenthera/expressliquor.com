const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

// ── helpers ────────────────────────────────────────────────────────────────

const EMAIL_RE = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
// Strict phone regex — only matches formatted numbers (must have separators or country code)
const PHONE_RE =
  /(?:\+\d{1,3}[\s\-.])?(?:\(\d{3}\)[\s\-.]?\d{3}[\s\-.]\d{4}|\d{3}[\s\-.]\d{3}[\s\-.]\d{4}|\(\d{3}\)\d{3}[\s\-.]\d{4})/g;

const SOCIAL = {
  linkedin: /linkedin\.com\/(company|in)\/[^\s"'><)]+/i,
  instagram: /instagram\.com\/[^\s"'><)]+/i,
  facebook: /facebook\.com\/[^\s"'><)]+/i,
  x: /(?:twitter|x)\.com\/[^\s"'><)]+/i,
  threads: /threads\.net\/[^\s"'><)]+/i,
};

function normaliseUrl(base, href) {
  if (!href) return null;
  href = href.trim();
  if (href.startsWith('http')) return href;
  if (href.startsWith('//')) return 'https:' + href;
  try {
    return new URL(href, base).href;
  } catch {
    return null;
  }
}

function ensureProtocol(url) {
  url = url.trim();
  if (!url.startsWith('http')) url = 'https://' + url;
  return url;
}

async function fetchPage(url, timeout = 12000) {
  try {
    const res = await axios.get(url, {
      timeout,
      maxRedirects: 6,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 ' +
          '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });
    return res.data;
  } catch {
    return null;
  }
}

// ── extraction helpers ─────────────────────────────────────────────────────

function extractEmails(text) {
  const raw = text.match(EMAIL_RE) || [];
  const badExt = /\.(png|jpg|jpeg|gif|svg|css|js|woff|ttf|ico)$/i;
  const badDomains = /sentry[\-.]|wixpress\.com|noreply|no-reply|example\.com|yourdomain|user@domain/i;
  const badLocal = /^(your|user|name|email|info@example|test@|john@doe)/i;
  return [
    ...new Set(
      raw.filter(
        e =>
          !badExt.test(e) &&
          !badDomains.test(e) &&
          !badLocal.test(e) &&
          !/^[0-9a-f]{32}@/i.test(e),
      ),
    ),
  ];
}

function collectPhones($, html) {
  const found = new Set();

  // Strategy 1: tel: href links (most reliable)
  $('a[href^="tel:"]').each((_, el) => {
    const raw = $(el).attr('href').replace('tel:', '').trim();
    if (raw) found.add(raw);
  });

  // Strategy 2: JSON-LD schema.org
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const data = JSON.parse($(el).html());
      const items = Array.isArray(data) ? data : [data];
      for (const item of items) {
        if (item.telephone) found.add(item.telephone);
        if (item.contactPoint?.telephone) found.add(item.contactPoint.telephone);
      }
    } catch {}
  });

  // Strategy 3: microdata
  $('[itemprop="telephone"]').each((_, el) => {
    const v = $(el).attr('content') || $(el).text().trim();
    if (v) found.add(v);
  });

  // Strategy 4: formatted numbers near phone-related keywords
  const visibleText = html.replace(/<[^>]+>/g, ' ');
  const labelRe = /(?:phone|tel(?:ephone)?|call us|mobile|fax)[:\s]*([\+\d\s\(\)\-\.]{7,20})/gi;
  let m;
  while ((m = labelRe.exec(visibleText)) !== null) {
    const candidate = m[1].trim();
    const digits = candidate.replace(/\D/g, '');
    if (digits.length >= 7 && digits.length <= 15 && !/^(\d)\1{6,}$/.test(digits)) {
      found.add(candidate);
    }
  }

  // Strategy 5: strictly-formatted numbers anywhere in visible text
  const strictMatches = visibleText.match(PHONE_RE) || [];
  for (const p of strictMatches) {
    const digits = p.replace(/\D/g, '');
    if (!/^(\d)\1{6,}$/.test(digits)) found.add(p.trim());
  }

  return [...found];
}

function deduplicatePhones(rawList) {
  function digitKey(raw) {
    let d = decodeURIComponent(raw).replace(/\D/g, '');
    if (d.length === 11 && d.startsWith('1')) d = d.slice(1);
    return d;
  }
  const score = s => (s.match(/[\(\)\-\. ]/g) || []).length;
  const byDigits = new Map();
  for (const raw of rawList) {
    const clean = decodeURIComponent(raw).trim();
    const key = digitKey(clean);
    if (key.length < 7 || key.length > 10) continue;
    if (/^(\d)\1{6,}$/.test(key)) continue;
    if (!byDigits.has(key) || score(clean) > score(byDigits.get(key))) {
      byDigits.set(key, clean);
    }
  }
  return [...byDigits.values()];
}

function extractSocials($, html) {
  const result = {};
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href') || '';
    for (const [key, re] of Object.entries(SOCIAL)) {
      if (!result[key] && re.test(href)) {
        const m = href.match(re);
        result[key] = m ? 'https://' + m[0] : href;
      }
    }
  });
  for (const [key, re] of Object.entries(SOCIAL)) {
    if (!result[key]) {
      const m = html.match(re);
      if (m) result[key] = 'https://' + m[0];
    }
  }
  return result;
}

function extractCompanyName($) {
  return (
    $('meta[property="og:site_name"]').attr('content') ||
    $('meta[name="application-name"]').attr('content') ||
    $('title').text().split(/[|\-–—]/)[0].trim() ||
    ''
  );
}

function hasContactForm($) {
  let found = false;
  $('form').each((_, form) => {
    const f = $(form);
    const text = f.text().toLowerCase() + f.html().toLowerCase();
    const hasMsg =
      f.find('textarea').length > 0 ||
      text.includes('message') ||
      text.includes('enquir') ||
      text.includes('inquiry') ||
      text.includes('contact');
    if (hasMsg) { found = true; return false; }
  });
  return found;
}

function hasQuoteForm($) {
  let found = false;
  $('form').each((_, form) => {
    const f = $(form);
    const text = f.text().toLowerCase() + (f.attr('id') || '') + (f.attr('class') || '');
    if (text.includes('quote') || text.includes('estimate') || text.includes('pricing')) {
      found = true; return false;
    }
  });
  if (!found) {
    $('a, button').each((_, el) => {
      const t = ($(el).text() + $(el).attr('href') + $(el).attr('id') + $(el).attr('class'))
        .toLowerCase();
      if (t.includes('quote') || t.includes('get a quote') || t.includes('free quote')) {
        found = true; return false;
      }
    });
  }
  return found;
}

function guessDomain(text) {
  const keywords = {
    'Technology': ['software', 'tech', 'it services', 'cloud', 'saas', 'app development'],
    'Marketing': ['marketing', 'seo', 'digital marketing', 'advertising', 'branding'],
    'Construction': ['construction', 'builder', 'contractor', 'renovation', 'roofing'],
    'Healthcare': ['health', 'medical', 'clinic', 'dental', 'hospital', 'care'],
    'Finance': ['finance', 'accounting', 'insurance', 'investment', 'tax'],
    'Real Estate': ['real estate', 'property', 'realty', 'homes for sale'],
    'Education': ['school', 'education', 'tutoring', 'learning', 'academy', 'university'],
    'E-commerce': ['shop', 'store', 'buy', 'cart', 'checkout', 'product'],
    'Legal': ['law', 'attorney', 'lawyer', 'legal', 'solicitor'],
    'Hospitality': ['hotel', 'restaurant', 'travel', 'tourism', 'catering'],
    'Cleaning': ['cleaning', 'janitorial', 'maid', 'housekeeping'],
    'Landscaping': ['landscaping', 'lawn', 'garden', 'tree service'],
    'Automotive': [' auto ', 'car dealer', 'vehicle', 'mechanic', 'dealership', 'automotive'],
    'Design': ['design', 'creative', 'graphic', 'web design', 'ui/ux'],
    'Solar / Energy': ['solar', 'renewable', 'energy', 'photovoltaic', 'panel installation'],
  };
  const lower = text.toLowerCase();
  for (const [domain, terms] of Object.entries(keywords)) {
    if (terms.some(t => lower.includes(t))) return domain;
  }
  return 'Other';
}

function findContactPageUrl($, baseUrl) {
  let contactUrl = null;
  $('a[href]').each((_, el) => {
    const href = ($(el).attr('href') || '').toLowerCase();
    const txt = $(el).text().toLowerCase();
    if (
      href.includes('contact') ||
      txt === 'contact' ||
      txt === 'contact us' ||
      txt === 'get in touch'
    ) {
      contactUrl = normaliseUrl(baseUrl, $(el).attr('href'));
      return false;
    }
  });
  return contactUrl;
}

// ── core scrape ────────────────────────────────────────────────────────────

async function scrapeWebsite(rawUrl, onLog) {
  const log = msg => { if (onLog) onLog(msg); else console.log(msg); };
  const url = ensureProtocol(rawUrl);
  log(`Fetching home: ${url}`);

  const homeHtml = await fetchPage(url);
  if (!homeHtml) {
    log(`Could not reach ${url}`);
    return buildRow(rawUrl, { notReachable: true });
  }

  const $ = cheerio.load(homeHtml);
  const homeText = $.text();

  const companyName = extractCompanyName($);
  let emails = extractEmails(homeHtml);
  let rawPhones = collectPhones($, homeHtml);
  const socials = extractSocials($, homeHtml);
  let contactForm = hasContactForm($);
  let quoteForm = hasQuoteForm($);
  const industry = guessDomain(homeText);
  const contactPageUrl = findContactPageUrl($, url);

  if (contactPageUrl && contactPageUrl !== url) {
    log(`Fetching contact: ${contactPageUrl}`);
    const contactHtml = await fetchPage(contactPageUrl);
    if (contactHtml) {
      const $c = cheerio.load(contactHtml);
      emails = [...new Set([...emails, ...extractEmails(contactHtml)])];
      rawPhones = [...rawPhones, ...collectPhones($c, contactHtml)];
      if (!contactForm) contactForm = hasContactForm($c);
      if (!quoteForm) quoteForm = hasQuoteForm($c);
      const cs = extractSocials($c, contactHtml);
      for (const [k, v] of Object.entries(cs)) {
        if (!socials[k]) socials[k] = v;
      }
    }
  }

  const phones = deduplicatePhones(rawPhones);

  return buildRow(rawUrl, {
    companyName,
    email: emails.join(' | '),
    phone: phones.join(' | '),
    industry,
    contactForm,
    quoteForm,
    notReachable: false,
    ...socials,
  });
}

function buildRow(url, d) {
  return {
    Website: url,
    'Not Reachable': d.notReachable ? 'Yes' : 'No',
    'Company Name': d.companyName || '',
    Email: d.email || '',
    Phone: d.phone || '',
    'Industry / Domain': d.industry || '',
    'Has Contact Form': d.contactForm ? 'Yes' : 'No',
    'Has Quote Form': d.quoteForm ? 'Yes' : 'No',
    LinkedIn: d.linkedin || '',
    Instagram: d.instagram || '',
    Facebook: d.facebook || '',
    'X (Twitter)': d.x || '',
    Threads: d.threads || '',
  };
}

// ── concurrency pool ───────────────────────────────────────────────────────

async function runPool(tasks, concurrency) {
  const results = new Array(tasks.length);
  let next = 0;
  async function worker() {
    while (next < tasks.length) {
      const i = next++;
      results[i] = await tasks[i]();
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));
  return results;
}

// ── CSV writer ─────────────────────────────────────────────────────────────

function toCSV(rows) {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const escape = v => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [headers.map(escape).join(',')];
  for (const row of rows) {
    lines.push(headers.map(h => escape(row[h])).join(','));
  }
  return lines.join('\n');
}

// ── exports (used by server.js) ────────────────────────────────────────────

module.exports = { scrapeWebsite, runPool, buildRow };

// ── CLI entry point ────────────────────────────────────────────────────────

if (require.main === module) {
  const listFile = path.resolve('website-list.txt');
  const outFile = path.resolve('results.csv');
  const CONCURRENCY = 10;

  if (!fs.existsSync(listFile)) {
    console.error(`✗ website-list.txt not found at ${listFile}`);
    process.exit(1);
  }

  const urls = fs
    .readFileSync(listFile, 'utf8')
    .split('\n')
    .map(l => l.trim())
    .filter(l => l && !l.startsWith('#'));

  console.log(`Scraping ${urls.length} website(s) with concurrency=${CONCURRENCY}…\n`);

  let done = 0;
  const tasks = urls.map((url, i) => async () => {
    console.log(`[${i + 1}/${urls.length}] ${url}`);
    const row = await scrapeWebsite(url);
    console.log(`  ✓ [${++done}/${urls.length}] done: ${url}`);
    return row;
  });

  runPool(tasks, CONCURRENCY).then(rows => {
    fs.writeFileSync(outFile, toCSV(rows), 'utf8');
    console.log(`\nResults saved to ${outFile}`);
  });
}
