const express = require('express');
const ExcelJS = require('exceljs');
const { scrapeWebsite, runPool } = require('./scraper');
const { randomUUID } = require('crypto');
const path = require('path');

const app = express();
const PORT = 3000;
const CONCURRENCY = 10;

// In-memory job store: jobId → { rows, total, done, logs, finished, error }
const jobs = new Map();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── POST /scrape — kick off a job ──────────────────────────────────────────
app.post('/scrape', (req, res) => {
  const raw = req.body.urls || '';
  const urls = raw
    .split('\n')
    .map(l => l.trim())
    .filter(l => l && !l.startsWith('#'));

  if (!urls.length) return res.status(400).json({ error: 'No URLs provided' });

  const jobId = randomUUID();
  const job = { rows: [], total: urls.length, done: 0, logs: [], finished: false, error: null };
  jobs.set(jobId, job);

  // Run scraping in background
  (async () => {
    try {
      let idx = 0;
      const tasks = urls.map(url => async () => {
        const n = ++idx;
        job.logs.push(`[${n}/${job.total}] Scraping ${url}…`);
        const row = await scrapeWebsite(url, msg => job.logs.push(`  ${msg}`));
        job.done++;
        job.rows.push(row);
        job.logs.push(`  ✓ Done (${job.done}/${job.total})`);
        return row;
      });
      await runPool(tasks, CONCURRENCY);
    } catch (err) {
      job.error = err.message;
    } finally {
      job.finished = true;
    }
  })();

  res.json({ jobId, total: urls.length });
});

// ── GET /progress/:jobId — SSE stream ─────────────────────────────────────
app.get('/progress/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).end();

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const send = data => res.write(`data: ${JSON.stringify(data)}\n\n`);

  let logOffset = 0;

  const interval = setInterval(() => {
    // Send any new log lines
    const newLogs = job.logs.slice(logOffset);
    if (newLogs.length) {
      logOffset += newLogs.length;
      send({ type: 'log', lines: newLogs });
    }

    send({ type: 'progress', done: job.done, total: job.total });

    if (job.finished) {
      clearInterval(interval);
      if (job.error) {
        send({ type: 'error', message: job.error });
      } else {
        send({ type: 'done' });
      }
      res.end();
    }
  }, 300);

  req.on('close', () => clearInterval(interval));
});

// ── GET /download/:jobId — serve Excel ────────────────────────────────────
app.get('/download/:jobId', async (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job || !job.finished) return res.status(404).json({ error: 'Job not ready' });

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Results');

  const rows = job.rows;
  if (!rows.length) return res.status(204).end();

  const headers = Object.keys(rows[0]);

  // Header row — styled
  ws.addRow(headers);
  const headerRow = ws.getRow(1);
  headerRow.eachCell(cell => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = {
      bottom: { style: 'thin', color: { argb: 'FF4A90D9' } },
    };
  });
  headerRow.height = 28;

  // Data rows
  rows.forEach((row, i) => {
    const values = headers.map(h => row[h]);
    const dataRow = ws.addRow(values);
    dataRow.eachCell(cell => {
      cell.alignment = { vertical: 'middle', wrapText: true };
      cell.fill = {
        type: 'pattern', pattern: 'solid',
        fgColor: { argb: i % 2 === 0 ? 'FFF5F8FF' : 'FFFFFFFF' },
      };
    });

    // Colour "Not Reachable" = Yes in red
    const nrIdx = headers.indexOf('Not Reachable') + 1;
    if (nrIdx && row['Not Reachable'] === 'Yes') {
      dataRow.getCell(nrIdx).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFCCCC' } };
      dataRow.getCell(nrIdx).font = { color: { argb: 'FFCC0000' }, bold: true };
    }

    // Colour Yes/No columns green/orange
    ['Has Contact Form', 'Has Quote Form'].forEach(col => {
      const ci = headers.indexOf(col) + 1;
      if (!ci) return;
      const val = row[col];
      dataRow.getCell(ci).font = {
        color: { argb: val === 'Yes' ? 'FF1A7A2F' : 'FFB05000' },
        bold: true,
      };
    });

    dataRow.height = 20;
  });

  // Auto column widths
  headers.forEach((h, i) => {
    const col = ws.getColumn(i + 1);
    const maxLen = Math.max(
      h.length,
      ...rows.map(r => String(r[h] || '').length).map(l => Math.min(l, 60)),
    );
    col.width = Math.max(12, maxLen + 2);
  });

  // Freeze header row
  ws.views = [{ state: 'frozen', ySplit: 1 }];

  const filename = `scrape-results-${new Date().toISOString().slice(0, 10)}.xlsx`;
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

  await wb.xlsx.write(res);
  res.end();

  // Clean up job after download
  jobs.delete(req.params.jobId);
});

app.listen(PORT, () => {
  console.log(`\n  Website Scraper UI → http://localhost:${PORT}\n`);
});
